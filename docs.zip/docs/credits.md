Inspired by gists from this author

<https://gist.github.com/notsure2>

Ideas exchanged with this project

https://github.com/c0re100/qBittorrent-Enhanced-Edition
